library(testthat)
library(MEMA)

test_check("MEMA")
